import pandas as pd
import matplotlib.pyplot as plt

# Read Excel file
df = pd.read_excel("sales_data.xlsx")

# Calculate sales and profit
df["Sales"] = df["Quantity"] * df["Price"]
df["Profit"] = (df["Price"] - df["Cost"]) * df["Quantity"]

# Total sales and profit
total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()

# Product-wise quantity
product_quantity = df.groupby("Product")["Quantity"].sum()

# Best selling product
best_product = product_quantity.idxmax()

# Product-wise sales
product_sales = df.groupby("Product")["Sales"].sum()

# Monthly sales
df["Month"] = df["Date"].dt.month_name()
monthly_sales = df.groupby("Month")["Sales"].sum()

# Monthly profit
monthly_profit = df.groupby("Month")["Profit"].sum()


# Display results
print("\n----- SALES ANALYSIS SYSTEM -----")

print("\nTotal Sales:", total_sales)
print("Total Profit:", total_profit)

print("\nBest Selling Product:", best_product)

print("\nProduct-wise Quantity:")
print(product_quantity)

print("\nMonthly Sales:")
print(monthly_sales)

print("\nMonthly Profit:")
print(monthly_profit)


# =====================================
# ALL GRAPHS IN ONE SCREEN
# =====================================

plt.figure(figsize=(12, 8))


# Graph 1: Monthly Sales
plt.subplot(2, 2, 1)

plt.bar(monthly_sales.index, monthly_sales.values)

plt.title("Monthly Sales")
plt.xlabel("Month")
plt.ylabel("Sales")

plt.xticks(rotation=45)


# Graph 2: Monthly Profit
plt.subplot(2, 2, 2)

plt.plot(
    monthly_profit.index,
    monthly_profit.values,
    marker="o"
)

plt.title("Monthly Profit")
plt.xlabel("Month")
plt.ylabel("Profit")

plt.xticks(rotation=45)

plt.grid()


# Graph 3: Product Quantity
plt.subplot(2, 2, 3)

plt.bar(
    product_quantity.index,
    product_quantity.values
)

plt.title("Product Quantity Sold")
plt.xlabel("Product")
plt.ylabel("Quantity")


# Graph 4: Product-wise Sales
plt.subplot(2, 2, 4)

plt.pie(
    product_sales.values,
    labels=product_sales.index,
    autopct="%1.1f%%"
)

plt.title("Product-wise Sales")


# Adjust spacing
plt.tight_layout()

# Show all graphs in one screen
plt.show()